#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    std::cout << "Hello, World again!" << std::endl;
    std::cout << "Hello, World again!!" << std::endl;
    return 0;
}